import pandas as pd
import numpy as np
from sklearn import metrics
from scipy import stats
from statsmodels.stats.outliers_influence import variance_inflation_factor
import seaborn as sns
import matplotlib.pyplot as plt

def get_cooksd(model_obj, df_train):
    
    # Get influence measures
    influence = model_obj.get_influence()
    influence

    # Obtain summary df of influence measures
    summ_df = influence.summary_frame()

    # Filter summary df to Cook distance
    diagnosis_df = summ_df.loc[:,['cooks_d']]

    # Append absolute standardized residual values
    diagnosis_df['std_resid'] = stats.zscore(model_obj.resid_pearson)
    diagnosis_df['std_resid'] = diagnosis_df.loc[:,'std_resid'].apply(lambda x: np.abs(x))

    # Sort by Cook's Distance
    diagnosis_df.sort_values("cooks_d", ascending=False)
    diagnosis_df

    # Set Cook's distance threshold
    cook_threshold = 4 / len(df_train)
    print(f"Threshold for Cook Distance = {cook_threshold}")

    # Find number of observations that exceed Cook's distance threshold
    outliers = diagnosis_df[diagnosis_df['cooks_d'] > cook_threshold]

    prop_outliers = round(100*(len(outliers) / len(df_train)),1)

    print(f'Proportion of data points that are highly influential = {prop_outliers}%')

    # Find number of observations which are BOTH outlier (std dev > 3) and highly influential
    extreme = diagnosis_df[(diagnosis_df['cooks_d'] > cook_threshold) & 
                           (diagnosis_df['std_resid'] > 3)]

    prop_extreme = round(100*(len(extreme) / len(df_train)),1)

    print(f'Proportion of highly influential outliers = {prop_extreme}%')

    res = {"cooksd": outliers,
          "threshold": cook_threshold,
          "extreme": extreme}
    
    return res

def get_vif(df):
    vif = pd.DataFrame()
    vif["variables"] = df.columns
    vif["VIF"] = [variance_inflation_factor(df.values, i) for i in range(df.shape[1])]
    return(vif)

def get_model_metrics(y, pred, y_test, pred_test):
    
    def model_metrics(y, pred):
        return pd.DataFrame({"Accuracy": [metrics.accuracy_score(y, pred)],
                           "Precision":[metrics.precision_score(y, pred, pos_label=0)],
                           "Recall": [metrics.recall_score(y, pred, pos_label=0)],
                           "F05": [metrics.fbeta_score(y, pred, pos_label=0, beta=0.5)],
                           "F1": [metrics.f1_score(y, pred, pos_label=0)],
                           "F2": [metrics.fbeta_score(y, pred, pos_label=0, beta=2)],
                           "AUC": [metrics.roc_auc_score(y, pred)],
                           "GINI": [2*metrics.roc_auc_score(y, pred)-1] })
    
    return {"Test": model_metrics(y=y_test, pred=pred_test),
            "Train": model_metrics(y=y, pred=pred)}

def get_roc_plot(y, pred):
    
    # Get Roc Curves
    fpr, tpr, thresholds = metrics.roc_curve(y, pred)

    gmeans = np.sqrt(tpr * (1 - fpr))
    ix = np.argmax(gmeans)
    print("Best Threshold=%f, G-Mean=%.3f" % (thresholds[ix], gmeans[ix]))
    thresh = thresholds[ix]
    pred = [1 if p >= thresh else 0 for p in pred]

    plt.clf()
    plt.figure(figsize=(8, 8))
    sns.set(font_scale=2)

    plt.plot([0, 1], [0, 1], linestyle="--", label="No Skill")
    plt.plot(fpr, tpr, marker=".", label="Model")

    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("Roc")
    plt.legend()
    plt.show()
    plt.clf()
    
    
    
    
